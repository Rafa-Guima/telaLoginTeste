package com.example.telateste;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.Toast;

import com.example.API.ServidorConfig;
import com.example.Utils.Criptografia;
import com.google.android.material.button.MaterialButton;

import org.json.JSONObject;

import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class LoginPage extends AppCompatActivity {

    EditText editLogin, editSenha;
    MaterialButton btnEntrar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_page);

        editLogin = findViewById(R.id.editLogin);
        editSenha = findViewById(R.id.editSenha);
        btnEntrar = findViewById(R.id.btnEntrar);

        btnEntrar.setOnClickListener(v -> {
            String login = editLogin.getText().toString().trim();
            String senha = editSenha.getText().toString().trim();

            if (login.isEmpty() || senha.isEmpty()) {
                Toast.makeText(this, "Preencha todos os campos!", Toast.LENGTH_SHORT).show();
                return;
            }

            new Thread(() -> {
                try {
                    JSONObject json = new JSONObject();

                    String loginCripto = Criptografia.criptografar(login);
                    String senhaCripto = Criptografia.criptografar(senha);

                    json.put("login", loginCripto);
                    json.put("senha", senhaCripto);

                    String baseUrl = ServidorConfig.getUrl("login");
                    URL url = new URL(baseUrl);
                    HttpURLConnection conexao = (HttpURLConnection) url.openConnection();
                    conexao.setRequestMethod("POST");
                    conexao.setRequestProperty("Content-Type", "application/json");
                    conexao.setDoOutput(true);

                    OutputStream os = conexao.getOutputStream();
                    os.write(json.toString().getBytes());
                    os.flush();
                    os.close();

                    int responseCode = conexao.getResponseCode();
                    if (responseCode == HttpURLConnection.HTTP_OK) {
                        BufferedReader reader = new BufferedReader(new InputStreamReader(conexao.getInputStream()));
                        StringBuilder sb = new StringBuilder();
                        String linha;
                        while ((linha = reader.readLine()) != null) {
                            sb.append(linha);
                        }

                        JSONObject resposta = new JSONObject(sb.toString());
                        JSONObject usuario = resposta.getJSONObject("usuario");
                        int idUsuario = usuario.getInt("id");

                        runOnUiThread(() -> {
                            Toast.makeText(this, "Login bem-sucedido!", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(this, PosLoginTela.class);
                            intent.putExtra("idUsuario", idUsuario);
                            startActivity(intent);
                        });

                    } else {
                        runOnUiThread(() -> Toast.makeText(this, "Usuário ou senha incorretos!", Toast.LENGTH_SHORT).show());
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                    runOnUiThread(() -> Toast.makeText(this, "Erro na requisição: " + e.getMessage(), Toast.LENGTH_LONG).show());
                }
            }).start();
        });
    }
}
