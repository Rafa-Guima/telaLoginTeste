package com.example.telateste;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.example.API.ServidorConfig;


public class SplashActivity extends AppCompatActivity {

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final int INTERVALO_TENTATIVA_MS = 1500;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_splash);

        // (Opcional) só se você tiver o ID "main"
        // ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), ...);

        tentarDetectarServidor();
    }

    private void tentarDetectarServidor() {
        ServidorConfig.detectarServidor(this, () -> {
            String servidorUsado = ServidorConfig.getUrl("");
            Log.d("ServidorDetectado", "Servidor ativo: " + servidorUsado);
            Toast.makeText(this, "✅ Conectado ao servidor!", Toast.LENGTH_SHORT).show();

            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
            finish();

        }, () -> {
            Toast.makeText(this, "❌ Servidor indisponível. Tentando novamente...", Toast.LENGTH_SHORT).show();
            Log.w("ServidorDetectado", "Servidor ainda não disponível. Tentando novamente...");
            handler.postDelayed(this::tentarDetectarServidor, INTERVALO_TENTATIVA_MS);
        });
    }
}
