
package com.example.API;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import org.json.JSONObject;

public class PassageiroAPI {

    public static String listarTodos() {
        StringBuilder resultado = new StringBuilder();

        try {
            String baseUrl = ServidorConfig.getUrl("passageiro");
            if (baseUrl == null) return "Erro: Servidor não detectado.";

            URL url = new URL(baseUrl);
            HttpURLConnection conexao = (HttpURLConnection) url.openConnection();
            conexao.setRequestMethod("GET");

            BufferedReader reader = new BufferedReader(new InputStreamReader(conexao.getInputStream()));
            String linha;
            while ((linha = reader.readLine()) != null) {
                resultado.append(linha);
            }
            reader.close();
        } catch (Exception e) {
            return "Erro: " + e.getMessage();
        }

        return resultado.toString();
    }

    public static String buscarPorId(int id) {
        StringBuilder resultado = new StringBuilder();

        try {
            String baseUrl = ServidorConfig.getUrl("passageiro");
            if (baseUrl == null) return "Erro: Servidor não detectado.";

            URL url = new URL(baseUrl + "/" + id);
            HttpURLConnection conexao = (HttpURLConnection) url.openConnection();
            conexao.setRequestMethod("GET");

            BufferedReader reader = new BufferedReader(new InputStreamReader(conexao.getInputStream()));
            String linha;
            while ((linha = reader.readLine()) != null) {
                resultado.append(linha);
            }
            reader.close();
        } catch (Exception e) {
            return "Erro: " + e.getMessage();
        }

        return resultado.toString();
    }

    public static String cadastrar(JSONObject passageiro) {
        StringBuilder resultado = new StringBuilder();

        try {
            String baseUrl = ServidorConfig.getUrl("passageiro");

            if (baseUrl == null) return "Erro: Servidor não detectado.";
            URL url = new URL(baseUrl);
            HttpURLConnection conexao = (HttpURLConnection) url.openConnection();

            conexao.setRequestMethod("POST");
            conexao.setRequestProperty("Accept", "application/json");
            conexao.setRequestProperty("Content-Type", "application/json; charset=UTF-8"); // ← charset muito importante
            conexao.setDoOutput(true);
            conexao.setDoInput(true);

            // DEBUG
            System.out.println("📤 Enviando JSON: " + passageiro.toString());

            // Use UTF-8 corretamente ao enviar os dados
            OutputStream os = conexao.getOutputStream();
            byte[] input = passageiro.toString().getBytes("utf-8");
            os.write(input, 0, input.length);
            os.flush();
            os.close();

            int statusCode = conexao.getResponseCode();
            System.out.println("🔍 Código HTTP: " + statusCode);

            BufferedReader reader = new BufferedReader(new InputStreamReader(
                    statusCode >= 200 && statusCode < 300 ?
                            conexao.getInputStream() : conexao.getErrorStream(), "utf-8"
            ));

            String linha;
            while ((linha = reader.readLine()) != null) {
                resultado.append(linha);
            }
            reader.close();

            System.out.println("📨 RESPOSTA SERVIDOR: " + resultado.toString());

        } catch (Exception e) {
            e.printStackTrace();
            return "Erro: " + e.getMessage();
        }

        return resultado.toString();
    }


    public static String atualizar(int id, JSONObject passageiro) {
        StringBuilder resultado = new StringBuilder();

        try {
            String baseUrl = ServidorConfig.getUrl("passageiro");
            if (baseUrl == null) return "Erro: Servidor não detectado.";

            URL url = new URL(baseUrl + "/" + id);
            HttpURLConnection conexao = (HttpURLConnection) url.openConnection();
            conexao.setRequestMethod("PUT");
            conexao.setRequestProperty("Content-Type", "application/json; utf-8");
            conexao.setDoOutput(true);

            OutputStream os = conexao.getOutputStream();
            os.write(passageiro.toString().getBytes("UTF-8"));
            os.close();

            BufferedReader reader = new BufferedReader(new InputStreamReader(conexao.getInputStream()));
            String linha;
            while ((linha = reader.readLine()) != null) {
                resultado.append(linha);
            }
            reader.close();
        } catch (Exception e) {
            return "Erro: " + e.getMessage();
        }

        return resultado.toString();
    }

    public static String deletar(int id) {
        StringBuilder resultado = new StringBuilder();

        try {
            String baseUrl = ServidorConfig.getUrl("passageiro");
            if (baseUrl == null) return "Erro: Servidor não detectado.";

            URL url = new URL(baseUrl + "/" + id);
            HttpURLConnection conexao = (HttpURLConnection) url.openConnection();
            conexao.setRequestMethod("DELETE");

            BufferedReader reader = new BufferedReader(new InputStreamReader(conexao.getInputStream()));
            String linha;
            while ((linha = reader.readLine()) != null) {
                resultado.append(linha);
            }
            reader.close();
        } catch (Exception e) {
            return "Erro: " + e.getMessage();
        }

        return resultado.toString();
    }

}
