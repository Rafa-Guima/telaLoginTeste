package com.example.telateste;


import android.os.Bundle;
import android.widget.EditText;
import android.widget.Toast;


import com.example.API.ServidorConfig;
import com.example.Utils.Criptografia;
import com.google.android.material.button.MaterialButton;

import org.json.JSONException;
import org.json.JSONObject;

import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class LoginPage extends AppCompatActivity {

    EditText editLogin, editSenha;
    MaterialButton btnEntrar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_page);

        editLogin = findViewById(R.id.editLogin);
        editSenha = findViewById(R.id.editSenha);
        btnEntrar = findViewById(R.id.btnEntrar);

        btnEntrar.setOnClickListener(v -> {
            String login = editLogin.getText().toString().trim();
            String senha = editSenha.getText().toString().trim();

            if (login.isEmpty() || senha.isEmpty()) {
                Toast.makeText(this, "Preencha todos os campos!", Toast.LENGTH_SHORT).show();
                return;
            }

            JSONObject json = new JSONObject();
            try {
                json.put("login", login);
                String senhaCripto = Criptografia.criptografar(senha);
                json.put("senha", senhaCripto);
            } catch (JSONException e) {
                e.printStackTrace();
            }

            new Thread(() -> {
                try {
                    String urlLogin = ServidorConfig.getUrl("login");
                    URL url = new URL(urlLogin);
                    HttpURLConnection conexao = (HttpURLConnection) url.openConnection();
                    conexao.setRequestMethod("POST");
                    conexao.setRequestProperty("Content-Type", "application/json; utf-8");
                    conexao.setDoOutput(true);

                    OutputStream os = conexao.getOutputStream();
                    os.write(json.toString().getBytes("UTF-8"));
                    os.close();

                    BufferedReader reader = new BufferedReader(new InputStreamReader(conexao.getInputStream()));
                    StringBuilder resultado = new StringBuilder();
                    String linha;
                    while ((linha = reader.readLine()) != null) {
                        resultado.append(linha);
                    }
                    reader.close();

                    runOnUiThread(() -> {
                        Toast.makeText(this, "Login bem-sucedido!", Toast.LENGTH_SHORT).show();
                        // startActivity(new Intent(this, HomePage.class));
                    });

                } catch (Exception e) {
                    e.printStackTrace();
                    runOnUiThread(() -> Toast.makeText(this, "Erro no login: " + e.getMessage(), Toast.LENGTH_LONG).show());
                }
            }).start();
        });
    }
}