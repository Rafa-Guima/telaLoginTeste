package com.example.API;

public interface OnServidorDetectado {
    void onDetectado();
}
